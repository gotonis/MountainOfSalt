*********************************************************
*		Expanded ZUN shotsheet by Ozzy/ExPorygon (v1.0)	*
*		Original by Helepolis							*
*********************************************************
This shotsheet contains most of the most commonly used bullet graphics in the official Touhou games. 

It also contains some lasers from Concealed the Conclusion and my own fireball graphics.

Some graphics were also touched up with Paint.net to make them stand out more, particularly the dark pellets. Some redundant shot colors were also replaced with new orange colors.		

	Added bullet types include:															
		-ADD-rendered Pellets															
		-ADD-rendered Amulets															
		-Large Round Bullets from PCB
		-ADD-Rendered Ovals
		-Dark Ovals
		-Dark Bubbles
		-Miko's Glowing Orbs
		-Futo's Arrows

	Instructions:
	-Include 'ZUNShot_Const.txt' with '#include' in your script.
	-Make sure that 'ZUNShot_Const.txt', 'ZUNShot.txt', and 'ZUNShot.png' are in the same directory.
	-Either fire the bullets with their numerical ID or use the contants in 'ZUNShot_Const.txt'.																