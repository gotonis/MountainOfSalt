*******************************************************************
*    Curvy Laser (Len Style) Function by Ozzy/ExPorygon (v1.0)    *
*******************************************************************

This function set is meant to imitate the curvy lasers used by Len in works such as Phantasmagoria Trues.

The lasers spawned by these functions are not in fact lasers at all, but simple bullets that create a trail of small lasers behind them.
Because of the large volume of lasers in the effect, these lasers are process intensive and can induce lag if a large number of them are 
coupled with a large amount of standard shots or other process intensive effects. That said, they're, in most cases, actually better in that
regard than Danmakufu's built in sinuate lasers (and CreateCurveLaserA1).

The function returns the object id of the head bullet, which is invisible and cannot hit the player. This shot can be controlled by any 
functions that can control standard shots. The laser trail spawns from this head bullet, so controlling it is the key to controlling 
the laser in its entirety.

You can use this function by including 'Function_CurvyLaser.dnh' with '#include' or copy pasting its contents into your script.

Parameters (for A1, varies slightly for the others, check 'Function_CurvyLaser.dnh' for more info):
1-X coordinate
2-Y coordinate
3-Speed
4-Angle
5-Length
6-Width
7-Laser trail graphic
8-Delay

-CreateCurvyLaserA1 is the standard function and will probably be used in most situations. To optimize for lag without sacrificing any of the
 effect, the rate at which the laser trails spawn varies with the speed of the head bullet.

-CreateCurvyLaserA2 is the same as A1 except the head bullet is visible and can be hit by the player. You can specify what bullet graphic to use
for the head bullet with an additional parameter

-CreateCurvyLaserB1 is the same as A1 except the rate at which the laser trails spawn can be controlled manually instead of automatically changing
with the speed. The rate at which they spawn can be specified with an additional paramter. A value of 2, for example, will cause a trail to spawn
every 2 frames. This can be used for more fine control of the lag that these lasers can produce. Setting the rate to less than 1 will raise an error.

-CreateCurvyLaserB2 is the same as A2 except the rate at which the laser trails spawn can be controlled manually as stated above.


NOTE: These lasers are not a perfect replacement for default sinuate lasers. The nature of the effect makes it difficult to make them make sharp turns at
anything but very low speeds without the effect breaking down. Please try to keep sharp turns to a minimum while using these. If you need something to make
something like this then you may need to use sinuate lasers instead. Experiment yourself to determine which is best for you to use.

One more thing, I guess it isn't completely necessary, but it would certainly be nice if you credit me when using this.